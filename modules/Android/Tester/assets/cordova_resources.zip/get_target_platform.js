Appery.getTargetPlatform = function() {
    return "#{targetPlatformSign}";
}
