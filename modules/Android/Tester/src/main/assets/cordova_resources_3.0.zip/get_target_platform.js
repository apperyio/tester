Appery.getTargetPlatform = function() {
    return "A";
}
